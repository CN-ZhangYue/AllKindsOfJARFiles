/**
 * SPI interfaces and configuration-related convenience classes for bean factories.
 */
@NonNullApi
@NonNullFields
package org.springframework.beans.factory.config;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
