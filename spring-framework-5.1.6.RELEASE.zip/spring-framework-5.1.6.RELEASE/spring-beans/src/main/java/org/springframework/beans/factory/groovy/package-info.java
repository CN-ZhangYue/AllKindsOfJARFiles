/**
 * Support package for Groovy-based bean definitions.
 */
package org.springframework.beans.factory.groovy;
