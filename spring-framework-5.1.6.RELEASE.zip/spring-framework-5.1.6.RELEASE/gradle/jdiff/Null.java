/**
 * This class is used only as a "null" argument for Javadoc when comparing
 * two API files. Javadoc has to have a package, .java or .class file as an
 * argument, even though JDiff doesn't use it.
 */
public class Null {
    public Null() {
    }
}
